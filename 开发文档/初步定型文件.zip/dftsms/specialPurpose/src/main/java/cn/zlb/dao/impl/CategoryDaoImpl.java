package cn.zlb.dao.impl;
import org.springframework.stereotype.Repository;

/**
 * 目录Dao
 * @author Bingo
 */
import cn.zlb.dao.CategoryDao;
import cn.zlb.entity.TStoreCategory;
@Repository("categoryDao")
public class CategoryDaoImpl extends BaseDaoImpl<TStoreCategory> implements CategoryDao {

	 

}

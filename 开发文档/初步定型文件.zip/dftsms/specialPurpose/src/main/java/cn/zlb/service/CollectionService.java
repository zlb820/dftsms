package cn.zlb.service;

public interface  CollectionService {
	public boolean findCollection(String cusId,String stoId);
}

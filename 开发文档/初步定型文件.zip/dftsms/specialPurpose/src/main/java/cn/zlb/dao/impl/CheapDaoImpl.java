package cn.zlb.dao.impl;
import org.springframework.stereotype.Repository;

import cn.zlb.dao.CheapDao;
import cn.zlb.entity.TCheap;
@Repository("cheapDao")
public class CheapDaoImpl extends BaseDaoImpl<TCheap> implements CheapDao {

 

}

package cn.zlb.dto.android.order;

public  class MesAndCod {
	private boolean isLogin=false;

	public boolean isLogin() {
		return isLogin;
	}

	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}

 
	
	
	
}

package cn.zlb.exception;

public class StoreNotFoundException extends RuntimeException {

	public StoreNotFoundException() {
		super();
	}

	public StoreNotFoundException(String message) {
		super(message);
	}
	

}

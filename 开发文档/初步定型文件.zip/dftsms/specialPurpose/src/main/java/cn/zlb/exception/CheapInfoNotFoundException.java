package cn.zlb.exception;

public class CheapInfoNotFoundException extends RuntimeException {

	public CheapInfoNotFoundException() {
		super();
	}

	public CheapInfoNotFoundException(String message) {
		super(message);
	}

}

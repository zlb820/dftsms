package cn.zlb.dao.impl;

import org.springframework.stereotype.Repository;

import cn.zlb.dao.ItemOrderDao;
import cn.zlb.entity.TItemorder;
@Repository("itemOrderDao")
public class ItemOrderDaoImpl extends BaseDaoImpl<TItemorder> implements ItemOrderDao {

	 }

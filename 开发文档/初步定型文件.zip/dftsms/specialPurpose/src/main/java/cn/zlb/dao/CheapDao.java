package cn.zlb.dao;
import cn.zlb.entity.TCheap;

public interface CheapDao extends BaseDao<TCheap>{
 

}

package cn.zlb.dto.android.order.orderDetail;

public class OrderDetailDtoAnd<T> {
	private T pageItems;

	public T getPageItems() {
		return pageItems;
	}

	public void setPageItems(T pageItems) {
		this.pageItems = pageItems;
	}
	
}

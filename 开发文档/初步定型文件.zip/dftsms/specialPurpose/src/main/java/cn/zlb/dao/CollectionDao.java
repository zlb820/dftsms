package cn.zlb.dao;

public interface CollectionDao {
	public boolean findCollection(String cusId,String stoId,String hql);
}

package cn.zlb.dao.impl;

import org.springframework.stereotype.Repository;

import cn.zlb.dao.AddressDao;
import cn.zlb.entity.TAddress;

@Repository("addressDao")
public class AddressDaoImpl extends BaseDaoImpl<TAddress> implements AddressDao {

	
}

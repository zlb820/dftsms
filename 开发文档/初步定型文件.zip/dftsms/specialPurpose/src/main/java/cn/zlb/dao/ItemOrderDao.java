package cn.zlb.dao;

import cn.zlb.entity.TItemorder;

public interface ItemOrderDao extends BaseDao<TItemorder> {

}

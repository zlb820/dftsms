package cn.zlb.dto.android.order;

 

public class OrderSuccess  extends MesAndCod {
	public String code="1";
	public String msg="修改成功";
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
}

package cn.zlb.dao;

import cn.zlb.entity.TAddress;

public interface AddressDao extends BaseDao<TAddress>{

}

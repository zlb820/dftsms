package cn.zlb.dao;

import cn.zlb.entity.TPictures;

public interface PictureDao extends BaseDao<TPictures>  {

}

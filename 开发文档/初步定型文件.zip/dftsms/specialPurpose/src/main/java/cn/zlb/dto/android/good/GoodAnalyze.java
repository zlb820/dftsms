package cn.zlb.dto.android.good;

public class GoodAnalyze {
	private String stoId;

	public String getStoId() {
		return stoId;
	}

	public void setStoId(String stoId) {
		this.stoId = stoId;
	}
	
}

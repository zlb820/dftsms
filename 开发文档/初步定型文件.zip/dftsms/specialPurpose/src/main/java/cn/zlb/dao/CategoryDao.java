package cn.zlb.dao;

import cn.zlb.entity.TStoreCategory;

public interface CategoryDao extends BaseDao<TStoreCategory>{

}

package cn.zlb.dto.android.order;
/**
 * 订单id 解析DTO
 * @author Bingo
 *
 */
public class OrderAnalyze {
	private String ordId;

	public String getOrdId() {
		return ordId;
	}

	public void setOrdId(String ordId) {
		this.ordId = ordId;
	}
	
}

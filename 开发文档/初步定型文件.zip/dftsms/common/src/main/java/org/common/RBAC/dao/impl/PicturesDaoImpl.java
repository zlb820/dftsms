package org.common.RBAC.dao.impl;

import org.common.RBAC.dao.PicturesDao;
import org.common.RBAC.domain.Pictures;

public class PicturesDaoImpl extends BaseDaoImpl<Pictures> implements PicturesDao{

}

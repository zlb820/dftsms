package org.common.RBAC.dao.impl;

import org.common.RBAC.dao.LoginInfoDao;
import org.common.RBAC.domain.LoginInfo;

public class LoginInfoDaoImpl extends BaseDaoImpl<LoginInfo> implements LoginInfoDao {

}

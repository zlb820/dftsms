package org.common.RBAC.dao.impl;

import org.common.RBAC.dao.LoginInfoStatusDao;
import org.common.RBAC.domain.LoginInfoStatus;

public class LoginInfoStatusDaoImpl extends BaseDaoImpl<LoginInfoStatus> implements LoginInfoStatusDao {

}

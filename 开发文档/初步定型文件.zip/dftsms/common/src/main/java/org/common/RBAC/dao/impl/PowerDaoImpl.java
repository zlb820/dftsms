package org.common.RBAC.dao.impl;

import org.common.RBAC.dao.PowerDao;
import org.common.RBAC.domain.Power;

public class PowerDaoImpl extends BaseDaoImpl<Power> implements PowerDao{

}

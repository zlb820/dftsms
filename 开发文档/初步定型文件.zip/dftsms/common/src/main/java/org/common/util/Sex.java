package org.common.util;

public enum Sex {
	男, 女
}

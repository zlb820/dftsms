package org.common.FDBK.domain.DATA.Android;

import java.util.List;

public class LunBoTuOfAndroid {
	private String styleId="10";
	List<LBT_data> lbt;
	
	public String getStyleId() {
		return styleId;
	}

	public List<LBT_data> getLbt() {
		return lbt;
	}

	public void setLbt(List<LBT_data> lbt) {
		this.lbt = lbt;
	}

}

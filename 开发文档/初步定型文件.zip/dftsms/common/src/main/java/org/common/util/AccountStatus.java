package org.common.util;

public enum AccountStatus {
	关闭,激活
}

package org.common.RBAC.dao.impl;

import org.common.RBAC.dao.BaseDao;
import org.common.RBAC.domain.AccountModify;

public class AccountModifyDaoImpl extends BaseDaoImpl<AccountModify> implements BaseDao<AccountModify> {

}

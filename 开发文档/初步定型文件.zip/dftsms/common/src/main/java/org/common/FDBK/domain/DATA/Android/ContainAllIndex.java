package org.common.FDBK.domain.DATA.Android;


public class ContainAllIndex {
	private LunBoTuOfAndroid a_lbt;
	private BaoKuanTuiJian b_bktj;
	private TuiJianShangJia c_tjsj;
//	private List<ShopSimpleMSG> d_shopNode;
	public LunBoTuOfAndroid getA_lbt() {
		return a_lbt;
	}
	public void setA_lbt(LunBoTuOfAndroid a_lbt) {
		this.a_lbt = a_lbt;
	}
	public BaoKuanTuiJian getB_bktj() {
		return b_bktj;
	}
	public void setB_bktj(BaoKuanTuiJian b_bktj) {
		this.b_bktj = b_bktj;
	}
	public TuiJianShangJia getC_tjsj() {
		return c_tjsj;
	}
	public void setC_tjsj(TuiJianShangJia c_tjsj) {
		this.c_tjsj = c_tjsj;
	}
	// public List<ShopSimpleMSG> getD_shopNode() {
	// return d_shopNode;
	// }
	// public void setD_shopNode(List<ShopSimpleMSG> d_shopNode) {
	// this.d_shopNode = d_shopNode;
	// }
	
}

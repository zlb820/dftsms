package org.common.RBAC.dao;

import org.common.RBAC.domain.Role;

public interface RoleDao extends BaseDao<Role> {

}

package org.common.FDBK.domain.DATA.Android;

import java.util.List;

import org.common.FDBK.domain.DATA.ShopSimpleMSG;

public class OnlyStoreData {
	private List<ShopSimpleMSG> shopNode;

	public List<ShopSimpleMSG> getShopNode() {
		return shopNode;
	}

	public void setShopNode(List<ShopSimpleMSG> shopNode) {
		this.shopNode = shopNode;
	}
}

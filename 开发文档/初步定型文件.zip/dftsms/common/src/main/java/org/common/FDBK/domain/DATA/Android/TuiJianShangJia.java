package org.common.FDBK.domain.DATA.Android;

import java.util.List;

import org.common.FDBK.domain.DATA.Shangjia;

public class TuiJianShangJia {
	private String styleId="14";
	private List<Shangjia> tjsj;

	public List<Shangjia> getTjsj() {
		return tjsj;
	}


	public void setTjsj(List<Shangjia> tjsj) {
		this.tjsj = tjsj;
	}


	public String getStyleId() {
		return styleId;
	}
}

package org.common.FDBK.domain.DATA.Android;

public class DataToReturn<T> {
	private T pageItems;
	public T getPageItems() {
		return pageItems;
	}
	public void setPageItems(T pageItems) {
		this.pageItems = pageItems;
	}
}

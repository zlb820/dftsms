package org.common.RBAC.dao;

import org.common.RBAC.domain.LoginInfoStatus;

public interface LoginInfoStatusDao extends BaseDao<LoginInfoStatus>{

}

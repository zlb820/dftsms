package org.common.util;

public enum EmailStatus {
	未激活,激活成功
}


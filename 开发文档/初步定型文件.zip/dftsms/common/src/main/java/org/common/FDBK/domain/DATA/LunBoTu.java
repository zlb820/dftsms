package org.common.FDBK.domain.DATA;

public class LunBoTu {
	private String storeID;
	private String picURL;
	
	public String getStoreID() {
		return storeID;
	}
	public void setStoreID(String storeID) {
		this.storeID = storeID;
	}
	public String getPicURL() {
		return picURL;
	}
	public void setPicURL(String picURL) {
		this.picURL = picURL;
	} 
	
}

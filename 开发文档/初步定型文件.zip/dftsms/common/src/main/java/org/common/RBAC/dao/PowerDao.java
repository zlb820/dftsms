package org.common.RBAC.dao;

import org.common.RBAC.domain.Power;

public interface PowerDao extends BaseDao<Power>{

}

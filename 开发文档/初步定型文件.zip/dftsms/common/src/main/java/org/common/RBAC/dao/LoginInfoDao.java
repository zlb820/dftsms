package org.common.RBAC.dao;

import org.common.RBAC.domain.LoginInfo;

public interface LoginInfoDao extends BaseDao<LoginInfo>{

}

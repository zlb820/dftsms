package org.common.RBAC.dao;

import org.common.RBAC.domain.AccountModify;

public interface AccountModifyDao extends BaseDao<AccountModify>{

}

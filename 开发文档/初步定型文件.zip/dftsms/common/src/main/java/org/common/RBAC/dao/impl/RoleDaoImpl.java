package org.common.RBAC.dao.impl;

import org.common.RBAC.dao.RoleDao;
import org.common.RBAC.domain.Role;

public class RoleDaoImpl extends BaseDaoImpl<Role> implements RoleDao{
	
}

package taotai;
/**
 * 参数异常
 * @author fxb fanxiaobin.fxb@qq.com
 */
public class FormalParameterException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public FormalParameterException() {
		super("参数异常");
	}
}

package org.common.test.util.dbunittest;


/**
 * 功能：主要是为了测试数据文件中的数据是否正确，仅用于手动测试，不再自动化测试之内
 * 
 * @author fxb fanxiaobin.fxb@qq.com
 */
public class DbunitTableDataTest {
	public static void main(String[] args) {
	}
}
